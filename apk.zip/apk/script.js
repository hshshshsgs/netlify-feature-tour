let board = ["", "", "", "", "", "", "", "", ""];
let currentPlayer = "X";
let gameActive = true;

function createBoard() {
  const boardElement = document.getElementById("board");
  boardElement.innerHTML = "";
  board.forEach((cell, index) => {
    const cellElement = document.createElement("div");
    cellElement.classList.add("cell");
    cellElement.textContent = cell;
    cellElement.addEventListener("click", () => handleClick(index));
    boardElement.appendChild(cellElement);
  });
}

function handleClick(index) {
  if (board[index] !== "" || !gameActive) return;
  board[index] = currentPlayer;
  createBoard();
  if (checkWinner()) {
    document.getElementById("message").textContent = `اللاعب ${currentPlayer} فاز!`;
    gameActive = false;
    return;
  }
  if (!board.includes("")) {
    document.getElementById("message").textContent = "تعادل!";
    gameActive = false;
    return;
  }
  currentPlayer = currentPlayer === "X" ? "O" : "X";
}

function checkWinner() {
  const winningCombos = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // صفوف
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // أعمدة
    [0, 4, 8], [2, 4, 6]             // أقطار
  ];
  return winningCombos.some(combo => 
    board[combo[0]] && 
    board[combo[0]] === board[combo[1]] && 
    board[combo[1]] === board[combo[2]]
  );
}

function startGame() {
  board = ["", "", "", "", "", "", "", "", ""];
  currentPlayer = "X";
  gameActive = true;
  document.getElementById("message").textContent = "";
  createBoard();
}

startGame();